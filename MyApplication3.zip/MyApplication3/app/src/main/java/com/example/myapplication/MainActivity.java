package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    WebView webView;
   ImageView img;
    EditText ed1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView=findViewById(R.id.web1);
        ed1=findViewById(R.id.ed1);
        img=findViewById(R.id.img);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("http://www.google.com");
        WebSettings webSettings=webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1 = ed1.getText().toString();
                if (s1.equals("http://www.google.com")) {
                    s1 = s1;
                } else {
                    s1 = "https://www." + s1 + ".com";

                }
                webView.loadUrl(s1);
                ed1.setText(webView.getUrl());
                //Toast.makeText(MainActivity.this, ""+s1, Toast.LENGTH_SHORT).show();
            }
        });
       //
    }

    @Override
    public void onBackPressed() {
        if(webView.canGoBack())
        {
            webView.goBack();

        }
        else {
            super.onBackPressed();
        }
    }
}
